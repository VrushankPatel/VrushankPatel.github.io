export const personalInfo = {
  name: "Vrushank Patel",
  title: "Senior Software Developer at NASDAQ",
  email: "vrushankpatel5@gmail.com",
  phone: "+91 9601501725",
  location: "Bangalore, India",
  image: "https://vrushankpatel.github.io/img/profile-pic.jpg",
  github: "https://github.com/VrushankPatel",
  linkedin: "https://www.linkedin.com/in/vrushank-patel-6b5b48170/",
  codersrank: "https://profile.codersrank.io/user/vrushankpatel",
  bio: "Senior Software Developer with 5+ years of experience in building high-performance trading systems, cloud-native applications, and financial software. Expertise in Java, Spring Boot, and cloud technologies with a focus on scalable, secure solutions.",
};

export const skills = {
  languages: ["Java", "Python", "SQL"],
  frameworks: ["Spring Boot", "Hibernate", "Flask", "Apache Camel", "JUnit/Mockito"],
  databases: ["MySQL", "Informix"],
  cloud: ["Docker", "Kubernetes", "GitLab CI/CD", "TeamCity"],
  distributed: ["Apache Kafka", "Reactive Microservices", "REST/gRPC APIs"],
  tools: ["MapStruct", "Orika", "GitHub Copilot", "Diffblue Cover"]
};

export const experience = [
  {
    company: "NASDAQ",
    position: "Senior Software Developer",
    period: "Nov 2022 - Present",
    location: "Bangalore, IN",
    description: [
      "Developed and optimized Multi Matching Engine (MME) for 10M+ daily transactions across forex, equities, and crypto markets using Java and Spring framework",
      "Containerized services with Docker and orchestrated deployments on Kubernetes/Amazon EKS, reducing infrastructure costs",
      "Contributed to GitLab CI/CD pipelines for artifact publishing and vulnerability scanning (Prisma, SonarQube, Sonatype)",
      "Customized MOE framework for Amazon EKS deployments, significantly reducing setup time for LATAM customers",
      "Delivered 15+ product adaptations for customers across LATAM, US and EU, including onsite testing in Colombia",
      "Patched 50+ vulnerabilities, reducing Sonatype threat score from 9→1.5",
      "Revamped 2500+ JUnit/Mockito test cases, achieving 90%+ code coverage",
    ],
  },
  {
    company: "Capsystematic Technologies Pvt Ltd",
    position: "Software Developer",
    period: "Dec 2019 - Nov 2022",
    location: "Bangalore, IN",
    description: [
      "Engineered capital markets and payment software using Java, Spring Boot, and Python Flask",
      "Developed Zeus-GPI middleware for processing ISO 20022 messages using SOAP and REST APIs",
      "Migrated legacy Pro*C code to modern Java architecture for Card Management System (CMS)",
      "Created CapSuite automation tool for generating code based on SQL procedures and Swift messages",
    ],
  },
  {
    company: "Capsystematic Technologies Pvt Ltd",
    position: "SDE Intern",
    period: "Sept 2019 - Dec 2019",
    location: "Bangalore, IN",
    description: [
      "Developed Apache Camel message routes and gained investment banking exposure",
    ],
  },
];

export const projects = [
  {
    title: "APEX",
    description: "High-performance trading platform for equity markets",
    technologies: ["Java", "Spring Boot", "Kubernetes", "Apache Kafka"],
    category: "Financial",
  },
  {
    title: "BlueLink",
    description: "Real-time payment processing and settlement system",
    technologies: ["Java", "Spring Boot", "MySQL", "Apache Camel"],
    category: "Payments",
  },
  {
    title: "Marketron",
    description: "Market data analytics and visualization platform",
    technologies: ["Python", "Flask", "React", "PostgreSQL"],
    category: "Analytics",
  },
  {
    title: "Maxine",
    description: "AI-powered trading strategy optimization system",
    technologies: ["Python", "TensorFlow", "FastAPI", "MongoDB"],
    category: "AI/ML",
  },
  {
    title: "Complexica",
    description: "Complex event processing engine for market data",
    technologies: ["Java", "Apache Flink", "Kafka", "Elasticsearch"],
    category: "Financial",
  },
  {
    title: "iBoard",
    description: "Executive dashboard for real-time business metrics",
    technologies: ["React", "D3.js", "Node.js", "GraphQL"],
    category: "Analytics",
  },
  {
    title: "Weathermon",
    description: "Weather monitoring and prediction system",
    technologies: ["Python", "scikit-learn", "FastAPI", "TimescaleDB"],
    category: "AI/ML",
  },
];

export const education = [
  {
    degree: "Bachelor of Engineering in Information Technology",
    institution: "Apollo Institute of Engineering (Gujarat Technological University)",
    period: "2015 - 2019",
    location: "Ahmedabad, India",
    grade: "CGPA: 8.24",
  },
];

export const blogs = [
  {
    title: "Building High-Performance Trading Systems",
    date: "2024-03-15",
    summary: "Insights into developing trading systems that handle millions of transactions daily",
    tags: ["Trading", "Java", "Performance"],
    readTime: "8 min",
  },
  {
    title: "Microservices in Financial Markets",
    date: "2024-03-01",
    summary: "Best practices for implementing microservices architecture in financial applications",
    tags: ["Microservices", "Architecture", "Finance"],
    readTime: "10 min",
  },
  {
    title: "Securing Financial Applications",
    date: "2024-02-15",
    summary: "Essential security practices for building robust financial software",
    tags: ["Security", "Best Practices", "Finance"],
    readTime: "12 min",
  },
];

export const achievements = [
  "Led development of high-performance trading system processing 10M+ daily transactions",
  "Reduced deployment setup time by 60% through infrastructure automation",
  "Improved system security by patching 50+ vulnerabilities",
  "Achieved 90%+ code coverage across 2500+ test cases",
  "Successfully delivered projects for major financial institutions across LATAM, US, and EU",
];

export const projectCategories = [
  "All",
  "Financial",
  "Payments",
  "Analytics",
  "AI/ML",
];