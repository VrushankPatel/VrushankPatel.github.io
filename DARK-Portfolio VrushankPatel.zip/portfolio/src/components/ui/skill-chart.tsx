import { useTheme } from "@/components/theme-provider";
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
} from "recharts";

interface SkillChartProps {
  data: {
    category: string;
    value: number;
  }[];
}

export function SkillChart({ data }: SkillChartProps) {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  return (
    <ResponsiveContainer width="100%" height={400}>
      <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
        <PolarGrid stroke={isDark ? "hsl(var(--muted-foreground))" : undefined} />
        <PolarAngleAxis
          dataKey="category"
          tick={{ fill: isDark ? "hsl(var(--foreground))" : undefined }}
        />
        <PolarRadiusAxis stroke={isDark ? "hsl(var(--muted-foreground))" : undefined} />
        <Radar
          name="Skills"
          dataKey="value"
          stroke="hsl(var(--primary))"
          fill="hsl(var(--primary))"
          fillOpacity={0.5}
        />
      </RadarChart>
    </ResponsiveContainer>
  );
}