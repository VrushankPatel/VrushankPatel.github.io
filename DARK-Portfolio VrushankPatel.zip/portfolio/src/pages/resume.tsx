import { personalInfo, skills, experience, education } from "@/data/portfolio";
import { Button } from "@/components/ui/button";
import { Download, Mail, Github, Linkedin } from "lucide-react";

export default function Resume() {
  return (
    <div className="max-w-4xl mx-auto p-8 bg-background text-foreground">
      <div className="flex justify-between items-start mb-8">
        <div>
          <h1 className="text-4xl font-bold">{personalInfo.name}</h1>
          <p className="text-xl text-muted-foreground mt-2">
            {personalInfo.title}
          </p>
          <div className="flex gap-4 mt-4">
            <a
              href={`mailto:${personalInfo.email}`}
              className="flex items-center text-muted-foreground hover:text-foreground"
            >
              <Mail className="h-4 w-4 mr-2" />
              {personalInfo.email}
            </a>
            <a
              href={personalInfo.github}
              className="flex items-center text-muted-foreground hover:text-foreground"
            >
              <Github className="h-4 w-4 mr-2" />
              GitHub
            </a>
            <a
              href={personalInfo.linkedin}
              className="flex items-center text-muted-foreground hover:text-foreground"
            >
              <Linkedin className="h-4 w-4 mr-2" />
              LinkedIn
            </a>
          </div>
        </div>
        <Button onClick={() => window.print()}>
          <Download className="mr-2 h-4 w-4" />
          Download PDF
        </Button>
      </div>

      <section className="mb-8">
        <h2 className="text-2xl font-bold mb-4">Summary</h2>
        <p className="text-muted-foreground">{personalInfo.bio}</p>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-bold mb-4">Skills</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Object.entries(skills).map(([category, items]) => (
            <div key={category}>
              <h3 className="font-semibold capitalize mb-2">{category}</h3>
              <p className="text-muted-foreground">{items.join(", ")}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-bold mb-4">Experience</h2>
        <div className="space-y-6">
          {experience.map((exp) => (
            <div key={exp.company}>
              <div className="flex justify-between mb-2">
                <div>
                  <h3 className="font-semibold">{exp.position}</h3>
                  <p className="text-muted-foreground">{exp.company}</p>
                </div>
                <p className="text-muted-foreground">{exp.period}</p>
              </div>
              <ul className="list-disc list-inside text-muted-foreground">
                {exp.description.map((item, index) => (
                  <li key={index}>{item}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-4">Education</h2>
        <div className="space-y-4">
          {education.map((edu) => (
            <div key={edu.institution}>
              <h3 className="font-semibold">{edu.degree}</h3>
              <p className="text-muted-foreground">{edu.institution}</p>
              <p className="text-muted-foreground">
                {edu.period} | {edu.location}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}