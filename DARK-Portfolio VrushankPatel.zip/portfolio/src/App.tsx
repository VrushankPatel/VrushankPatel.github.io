import { useState } from "react";
import { ThemeProvider } from "@/components/theme-provider";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ContactForm } from "@/components/ui/contact-form";
import {
  Github,
  Linkedin,
  Mail,
  MapPin,
  ExternalLink,
  Download,
  Phone,
} from "lucide-react";
import {
  personalInfo,
  skills,
  experience,
  projects,
  education,
  achievements,
  blogs,
  projectCategories,
} from "@/data/portfolio";

function App() {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredProjects = projects.filter((project) => {
    const matchesCategory =
      selectedCategory === "All" || project.category === selectedCategory;
    const matchesSearch =
      project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.technologies.some((tech) =>
        tech.toLowerCase().includes(searchQuery.toLowerCase())
      );
    return matchesCategory && matchesSearch;
  });

  return (
    <ThemeProvider defaultTheme="dark">
      <div className="min-h-screen bg-background text-foreground">
        {/* Header */}
        <header className="fixed top-0 w-full bg-background/80 backdrop-blur-sm border-b z-50">
          <div className="container mx-auto px-4 py-3 flex justify-between items-center">
            <h1 className="text-xl font-bold">{personalInfo.name}</h1>
            <div className="flex items-center gap-4">
              <Button variant="ghost" asChild>
                <a href="#contact">Contact</a>
              </Button>
              <Button variant="ghost" asChild>
                <a href="/resume">Resume</a>
              </Button>
              <ThemeToggle />
            </div>
          </div>
        </header>

        {/* Hero Section */}
        <section className="pt-24 pb-16 px-4">
          <div className="container mx-auto">
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="w-48 h-48 rounded-full overflow-hidden">
                <img
                  src={personalInfo.image}
                  alt={personalInfo.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 text-center md:text-left">
                <h1 className="text-4xl font-bold mb-4">{personalInfo.name}</h1>
                <h2 className="text-2xl text-muted-foreground mb-4">
                  {personalInfo.title}
                </h2>
                <p className="text-lg mb-6">{personalInfo.bio}</p>
                <div className="flex flex-wrap justify-center md:justify-start gap-4">
                  <Button
                    asChild
                    className="bg-[#24292e] hover:bg-[#1b1f23] text-white border-[#1b1f23]"
                  >
                    <a href={personalInfo.github}>
                      <Github className="mr-2 h-4 w-4" />
                      GitHub
                    </a>
                  </Button>
                  <Button
                    asChild
                    className="bg-[#0a66c2] hover:bg-[#004182] text-white border-[#004182]"
                  >
                    <a href={personalInfo.linkedin}>
                      <Linkedin className="mr-2 h-4 w-4" />
                      LinkedIn
                    </a>
                  </Button>
                  <Button
                    asChild
                    className="bg-[#ea4335] hover:bg-[#d33828] text-white border-[#d33828]"
                  >
                    <a href={`mailto:${personalInfo.email}`}>
                      <Mail className="mr-2 h-4 w-4" />
                      Email
                    </a>
                  </Button>
                  <Button
                    asChild
                    className="bg-[#25D366] hover:bg-[#128C7E] text-white border-[#128C7E]"
                  >
                    <a href={`tel:${personalInfo.phone}`}>
                      <Phone className="mr-2 h-4 w-4" />
                      Call
                    </a>
                  </Button>
                  <Button
                    asChild
                    className="bg-[#0ea5e9] hover:bg-[#0284c7] text-white border-[#0284c7]"
                  >
                    <a href="/resume" target="_blank">
                      <Download className="mr-2 h-4 w-4" />
                      Download Resume
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Projects Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">Projects</h2>
            <div className="mb-8">
              <div className="flex flex-wrap gap-4 mb-4">
                {projectCategories.map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? "default" : "outline"}
                    onClick={() => setSelectedCategory(category)}
                  >
                    {category}
                  </Button>
                ))}
              </div>
              <Input
                placeholder="Search projects..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="max-w-md"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProjects.map((project) => (
                <Card key={project.title} className="p-6">
                  <h3 className="text-xl font-semibold mb-2">
                    {project.title}
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="px-2 py-1 bg-secondary rounded-md text-xs"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Experience Section */}
        <section className="py-16 bg-muted/50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">Experience</h2>
            <div className="space-y-6">
              {experience.map((exp) => (
                <Card key={exp.company} className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-semibold">{exp.position}</h3>
                      <p className="text-muted-foreground">{exp.company}</p>
                      <p className="text-muted-foreground">{exp.location}</p>
                    </div>
                    <p className="text-muted-foreground">{exp.period}</p>
                  </div>
                  <ul className="list-disc list-inside space-y-2">
                    {exp.description.map((item, index) => (
                      <li key={index}>{item}</li>
                    ))}
                  </ul>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Blog Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">
              Technical Blog
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {blogs.map((blog) => (
                <Card key={blog.title} className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-xl font-semibold">{blog.title}</h3>
                    <span className="text-sm text-muted-foreground">
                      {blog.readTime}
                    </span>
                  </div>
                  <p className="text-muted-foreground mb-4">{blog.summary}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {blog.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-2 py-1 bg-secondary rounded-md text-xs"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <p className="text-sm text-muted-foreground">{blog.date}</p>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-16 bg-muted/50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">Contact Me</h2>
            <div className="max-w-xl mx-auto">
              <ContactForm />
            </div>
          </div>
        </section>

        {/* Skills Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">Technical Skills</h2>
            <div className="max-w-4xl mx-auto space-y-6">
              <div className="space-y-2">
                <h3 className="text-xl font-semibold text-blue-500">Programming Languages</h3>
                <p className="text-muted-foreground">{skills.languages.join(", ")}</p>
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-semibold text-green-500">Libraries & Frameworks</h3>
                <p className="text-muted-foreground">{skills.frameworks.join(", ")}</p>
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-semibold text-yellow-500">Databases</h3>
                <p className="text-muted-foreground">{skills.databases.join(", ")}</p>
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-semibold text-purple-500">Cloud, DevOps & CI/CD</h3>
                <p className="text-muted-foreground">{skills.cloud.join(", ")}</p>
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-semibold text-red-500">Distributed Systems</h3>
                <p className="text-muted-foreground">{skills.distributed.join(", ")}</p>
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-semibold text-orange-500">Development Tools</h3>
                <p className="text-muted-foreground">{skills.tools.join(", ")}</p>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-8 border-t">
          <div className="container mx-auto px-4 text-center">
            <div className="flex items-center justify-center gap-2 text-muted-foreground">
              <MapPin className="h-4 w-4" />
              <span>{personalInfo.location}</span>
            </div>
            <div className="flex items-center justify-center gap-4 mt-4">
              <a
                href={personalInfo.github}
                className="text-muted-foreground hover:text-foreground"
              >
                <Github className="h-5 w-5" />
              </a>
              <a
                href={personalInfo.linkedin}
                className="text-muted-foreground hover:text-foreground"
              >
                <Linkedin className="h-5 w-5" />
              </a>
              <a
                href={`mailto:${personalInfo.email}`}
                className="text-muted-foreground hover:text-foreground"
              >
                <Mail className="h-5 w-5" />
              </a>
            </div>
            <p className="mt-4 text-sm text-muted-foreground">
              © {new Date().getFullYear()} {personalInfo.name}. All rights
              reserved.
            </p>
          </div>
        </footer>
      </div>
    </ThemeProvider>
  );
}

export default App;